package BusPassManagementSystem;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class BoardingPoints extends javax.swing.JFrame {

    
    public BoardingPoints() {
        initComponents();
        Connect();
        table_update();
        Toolkit tk = getToolkit();
         Dimension size = tk.getScreenSize();
         setLocation(size.width/2-getWidth()/2,size.height/2-getHeight()/2);
    }

    Connection con;
    PreparedStatement pst;
    public void Connect()
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con =DriverManager.getConnection("jdbc:mysql://localhost:3306/buspassmanagementsystem","root","Shre@7473");
            System.out.println("Connected");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DriverRecords.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(DriverRecords.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
     private void table_update()
    {
        int CC;
        try{
        pst=con.prepareStatement("SELECT boardingpoint,vehicletype,fees,vehicleno FROM boardingpoint_fees");
        ResultSet Rs = pst.executeQuery();
        
        ResultSetMetaData RSMD = Rs.getMetaData();
        CC = RSMD.getColumnCount();
        DefaultTableModel DFT = (DefaultTableModel) jTable1.getModel();
        DFT.setRowCount(0);
        
        while (Rs.next())
        {
            Vector v2 = new Vector();
            
            for(int ii = 1; ii <= CC; ii++)
            {
                v2.add(Rs.getString("boardingpoint"));
                v2.add(Rs.getString("vehicletype"));
                v2.add(Rs.getString("fees"));
                v2.add(Rs.getString("vehicleno"));
            }
            DFT.addRow(v2);
        }
 
        }catch(Exception e){
    
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        driver = new javax.swing.JPanel();
        vehicletype = new javax.swing.JLabel();
        fees = new javax.swing.JLabel();
        vehicleno = new javax.swing.JLabel();
        boardingpoint = new javax.swing.JLabel();
        Bpoint = new java.awt.TextField();
        VehicleNo = new java.awt.TextField();
        VehicleType = new java.awt.TextField();
        Fees = new java.awt.TextField();
        delete = new javax.swing.JButton();
        insert = new javax.swing.JButton();
        edit = new javax.swing.JButton();
        back = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        driver.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        vehicletype.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        vehicletype.setText("Vehicle Type");

        fees.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        fees.setText("Fees");

        vehicleno.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        vehicleno.setText("Vehicle No");

        boardingpoint.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        boardingpoint.setText("Boarding Point");

        Bpoint.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        Bpoint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BpointActionPerformed(evt);
            }
        });

        VehicleNo.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N

        VehicleType.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N

        Fees.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        Fees.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FeesActionPerformed(evt);
            }
        });

        delete.setText("DELETE");
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });

        insert.setText("INSERT");
        insert.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                insertActionPerformed(evt);
            }
        });

        edit.setText("EDIT");
        edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editActionPerformed(evt);
            }
        });

        back.setText("BACK");
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout driverLayout = new javax.swing.GroupLayout(driver);
        driver.setLayout(driverLayout);
        driverLayout.setHorizontalGroup(
            driverLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(driverLayout.createSequentialGroup()
                .addGroup(driverLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(driverLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(boardingpoint)
                        .addGap(49, 49, 49)
                        .addComponent(Bpoint, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(driverLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(vehicletype, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(49, 49, 49)
                        .addComponent(VehicleType, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(driverLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(fees, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(49, 49, 49)
                        .addComponent(Fees, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(driverLayout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(vehicleno)
                        .addGap(81, 81, 81)
                        .addComponent(VehicleNo, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(driverLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(insert, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(delete, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)
                        .addComponent(edit, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(driverLayout.createSequentialGroup()
                        .addGap(60, 60, 60)
                        .addComponent(back, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        driverLayout.setVerticalGroup(
            driverLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(driverLayout.createSequentialGroup()
                .addGap(76, 76, 76)
                .addGroup(driverLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(boardingpoint, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Bpoint, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(driverLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(vehicletype, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(VehicleType, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(driverLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(fees, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Fees, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(driverLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(vehicleno, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(VehicleNo, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, 12, Short.MAX_VALUE)
                .addGroup(driverLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(insert, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(delete, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(edit, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(back, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(10, Short.MAX_VALUE))
        );

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Boarding Point", "Vehicle Type", "Fees", "Vehicle No"
            }
        ));
        jTable1.setShowHorizontalLines(true);
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 255, 51));
        jLabel1.setText("BOARDING POINTS - FEES RECORDS");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(driver, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 469, Short.MAX_VALUE)
                .addGap(14, 14, 14))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 641, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(driver, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(48, 48, 48))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BpointActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BpointActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BpointActionPerformed

    private void FeesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FeesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_FeesActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        int selectedIndex = jTable1.getSelectedRow();
        Bpoint.setText(model.getValueAt(selectedIndex, 0).toString());
        VehicleType.setText(model.getValueAt(selectedIndex, 1).toString());
        Fees.setText(model.getValueAt(selectedIndex, 2).toString());
        VehicleNo.setText(model.getValueAt(selectedIndex, 3).toString());

    }//GEN-LAST:event_jTable1MouseClicked

    private void insertActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_insertActionPerformed
        try {
            String boardingpoint,vehicletype,fees,vehicleno;
            boardingpoint=Bpoint.getText();
            vehicletype=VehicleType.getText();
            fees=Fees.getText();
            vehicleno=VehicleNo.getText();
            pst=con.prepareStatement("insert into boardingpoint_fees(stops,vehicletype,fees,vehicleno) values(?,?,?,?)");
            pst.setString(1, boardingpoint);
            pst.setString(2, vehicletype);
            pst.setString(3, fees);
            pst.setString(4, vehicleno);

            
                if(!boardingpoint.isEmpty())
            {
                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Record Saved");
                table_update();
            }
            else
            {
                JOptionPane.showMessageDialog(this, "Field is Empty");
            }
            Bpoint.setText("");
            VehicleType.setText("");
            Fees.setText("");
            VehicleNo.setText("");

            Bpoint.requestFocus();

        } catch (SQLException ex) {
            Logger.getLogger(DriverRecords.class.getName()).log(Level.SEVERE, null, ex);
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_insertActionPerformed

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
        try {
            String boardingpoint,vehicletype,fees,vehicleno;
            vehicleno=VehicleNo.getText();

            pst=con.prepareStatement("delete from boardingpoint_fees where vehicleno=?");
            pst.setString(1, vehicleno);
            
            
            if(!vehicleno.isEmpty())
            {
                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Record deleted");
                table_update();
            }
            else
            {
                JOptionPane.showMessageDialog(this, "Select row to Delete");
            }
            
            
            
            

            Bpoint.setText("");
            VehicleType.setText("");
            Fees.setText("");
            VehicleNo.setText("");

            Bpoint.requestFocus();

        } catch (SQLException ex) {
            Logger.getLogger(DriverRecords.class.getName()).log(Level.SEVERE, null, ex);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_deleteActionPerformed

    private void editActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editActionPerformed
        try {
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            int selectedIndex = jTable1.getSelectedRow();

            String boardingpoint,vehicletype,fees,vehicleno;
            boardingpoint=Bpoint.getText();
            vehicletype=VehicleType.getText();
            fees=Fees.getText();
            vehicleno=VehicleNo.getText();
            pst=con.prepareStatement("update boardingpoint_fees set boardingpoint=?,vehicletype=?,fees=? where vehicleno=?");

            pst.setString(1, boardingpoint);
            pst.setString(2, vehicletype);
            pst.setString(3, fees);
            pst.setString(4, vehicleno);

            
            if(!vehicleno.isEmpty())
            {
                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Record updated");
                table_update();
            }
            else
            {
                JOptionPane.showMessageDialog(this, "Select row to Update");
            }
            
            Bpoint.setText("");
            VehicleType.setText("");
            Fees.setText("");
            VehicleNo.setText("");

            Bpoint.requestFocus();

        } catch (SQLException ex) {
            Logger.getLogger(DriverRecords.class.getName()).log(Level.SEVERE, null, ex);
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_editActionPerformed

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        AdminHome.main(null);
        setVisible(false);
        // TODO add your handling code here:
    }//GEN-LAST:event_backActionPerformed

    
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BoardingPoints().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.TextField Bpoint;
    private java.awt.TextField Fees;
    private java.awt.TextField VehicleNo;
    private java.awt.TextField VehicleType;
    private javax.swing.JButton back;
    private javax.swing.JLabel boardingpoint;
    private javax.swing.JButton delete;
    private javax.swing.JPanel driver;
    private javax.swing.JButton edit;
    private javax.swing.JLabel fees;
    private javax.swing.JButton insert;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel vehicleno;
    private javax.swing.JLabel vehicletype;
    // End of variables declaration//GEN-END:variables
}
