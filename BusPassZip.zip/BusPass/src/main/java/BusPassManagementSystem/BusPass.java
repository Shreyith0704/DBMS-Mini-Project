package BusPassManagementSystem;
public class BusPass 
{
    public static void main(String[] args) 
    {
        System.out.println("main");
    }
}
